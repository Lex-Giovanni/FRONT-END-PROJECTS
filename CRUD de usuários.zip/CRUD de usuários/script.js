const usuarios = [];
let editandoIndex = null;
let contadorId = 1;

const inputNome = document.getElementById("nome");
const inputIdade = document.getElementById("idade");
const inputEmail = document.getElementById("email");

const campoBusca = document.getElementById("busca");
const selectOrdenacao = document.getElementById("ordenacao");

const botaoSalvar = document.getElementById("salvar");
const lista = document.getElementById("lista");

botaoSalvar.addEventListener("click", salvarUsuario);

campoBusca.addEventListener("input", listarUsuarios);
selectOrdenacao.addEventListener("change", listarUsuarios);

function salvarUsuario() {
    const nome = inputNome.value.trim();
    const idade = Number(inputIdade.value);
    const email = inputEmail.value.trim();

    // CAMPOS OBRIGATÓRIOS
    if (!nome || !idade || !email) {
        alert("Preencha todos os campos.");
        return;
    }

    // IDADE MÍNIMA
    if (idade < 18) {
        alert("A idade mínima é 18 anos.");
        return;
    }

    // EMAIL VÁLIDO
    const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailValido.test(email)) {
        alert("Digite um email válido.");
        return;
    }

    const usuario = {
        id: editandoIndex === null
            ? contadorId++
            : usuarios[editandoIndex].id,

        nome,
        idade,
        email,

        criadoEm: editandoIndex === null
            ? Date.now()
            : usuarios[editandoIndex].criadoEm
    };

    if (editandoIndex === null) {
        usuarios.push(usuario);
    } else {
        usuarios[editandoIndex] = usuario;
        editandoIndex = null;
        botaoSalvar.textContent = "Salvar";
    }

    limparCampos();
    listarUsuarios();
}

function listarUsuarios() {

    lista.innerHTML = "";

    let usuariosFiltrados = [...usuarios];

    // BUSCA
    const termo = campoBusca.value.toLowerCase();

    usuariosFiltrados = usuariosFiltrados.filter(usuario =>
        usuario.nome.toLowerCase().includes(termo) ||
        usuario.email.toLowerCase().includes(termo) ||
        usuario.id.toString().includes(termo)
    );

    // ORDENAÇÃO
    const tipoOrdenacao = selectOrdenacao.value;

    if (tipoOrdenacao === "az") {
        usuariosFiltrados.sort((a, b) =>
            a.nome.localeCompare(b.nome)
        );
    }

    if (tipoOrdenacao === "recentes") {
        usuariosFiltrados.sort((a, b) =>
            b.criadoEm - a.criadoEm
        );
    }

    if (tipoOrdenacao === "antigos") {
        usuariosFiltrados.sort((a, b) =>
            a.criadoEm - b.criadoEm
        );
    }

    usuariosFiltrados.forEach((usuario, index) => {

        const item = document.createElement("li");

        item.innerHTML = `
            <div>
                <strong>#${usuario.id} - ${usuario.nome}</strong><br>

                Idade: ${usuario.idade}<br>

                Email: ${usuario.email}
            </div>

            <div>
                <button onclick="editarUsuario(${usuarios.indexOf(usuario)})">
                    Editar
                </button>

                <button onclick="removerUsuario(${usuarios.indexOf(usuario)})">
                    Excluir
                </button>
            </div>
        `;

        lista.appendChild(item);
    });
}

function editarUsuario(index) {

    const usuario = usuarios[index];

    inputNome.value = usuario.nome;
    inputIdade.value = usuario.idade;
    inputEmail.value = usuario.email;

    editandoIndex = index;

    botaoSalvar.textContent = "Atualizar";
}

function removerUsuario(index) {

    usuarios.splice(index, 1);

    if (editandoIndex === index) {

        editandoIndex = null;

        limparCampos();

        botaoSalvar.textContent = "Salvar";
    }

    listarUsuarios();
}

function limparCampos() {

    inputNome.value = "";
    inputIdade.value = "";
    inputEmail.value = "";
}